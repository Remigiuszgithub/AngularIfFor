import { Component } from '@angular/core';

@Component({
  selector: 'app-react',
  imports: [],
  templateUrl: './react.component.html',
  styleUrl: './react.component.css'
})
export class ReactComponent {

}
