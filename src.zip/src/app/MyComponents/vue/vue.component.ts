import { Component } from '@angular/core';

@Component({
  selector: 'app-vue',
  imports: [],
  templateUrl: './vue.component.html',
  styleUrl: './vue.component.css'
})
export class VueComponent {

}
